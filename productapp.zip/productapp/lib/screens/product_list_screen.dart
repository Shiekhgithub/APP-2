// screens/product_list_screen.dart
import 'package:flutter/material.dart';
import '../models/product.dart';
import '../widgets/product_tile.dart';

class ProductListScreen extends StatelessWidget {
  final List<Product> products = [
    Product(
      id: '1',
      title: 'Laptop',
      description: 'High-performance laptop. Power and portability in one sleek design—your perfect on-the-go companion.',

      price: 999.99,
      imageUrl: 'https://via.placeholder.com/150',
    ),
    Product(
      id: '2',
      title: 'Smartphone',
      description: 'Latest smartphone with amazing features',
      price: 699.99,
      imageUrl: 'https://via.placeholder.com/150',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Product List')),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          return ProductTile(product: products[index]);
        },
      ),
    );
  }
}
